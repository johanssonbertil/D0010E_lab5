package Lab5.shopsimulator.shopevents;

import Lab5.genericsimulator.Event;
import Lab5.genericsimulator.EventQueue;
import Lab5.genericsimulator.State;
import Lab5.shopsimulator.ShopState;
import Lab5.shopsimulator.customer.Customer;

public class CloseEvent extends Event {

	public CloseEvent(State state, double time, EventQueue eventQueue) {
		super(state, time, eventQueue);
		// TODO Auto-generated constructor stub
	}

	public void doEvent() {
		((ShopState)state).canEnter = false;
		
	}

	public String name() {
		return "CloseEvent";
	}


}
