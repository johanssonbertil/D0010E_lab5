package Lab5.shopsimulator.shopevents;

import Lab5.genericsimulator.EventQueue;
import Lab5.genericsimulator.State;
import Lab5.shopsimulator.ShopState;
import Lab5.shopsimulator.customer.Customer;

public class PayEvent extends ShopEvent {

    public PayEvent(State state, double time, EventQueue eventQueue, Customer customer) {
    	super(state, time, eventQueue, customer);

    }

    public void doEvent(){
    	
    	((ShopState)state).customerLeavesCheckout();
    	if(!((ShopState)state).checkoutQueue.isEmpty()) {
    		Customer nextCustomer = ((ShopState)state).checkoutQueue.first();
    		((ShopState)state).checkoutQueue.removeFirst();
    		PayEvent event = new PayEvent(state, state.uniRNG.next(), eventQueue, nextCustomer);
            eventQueue.add(event);
            ((ShopState)state).peopleWhoHaveQueued++;
    	} else {
    		((ShopState)state).totalQueuingTime += time - ((ShopState)state).queuingStartedTime;
    		((ShopState)state).anotherCheckoutAvailable();
    		
    	}
    }

	@Override
	public String name() {
		return "PayEvent";
	}

}
