package Lab5.genericsimulator;


import Lab5.shopsimulator.ShopState;

import java.util.Observable;
import java.util.Observer;


public class View implements Observer{

	private Simulator sim;
	private State state;

	public View (Simulator simulator) {
		sim = simulator;
		simulator.addObserver(this);
	}



	public String lineBuilder(double tid, String event, int kund, String status, int led, double ledT, int currentCustomers,

								int cashOuts, int sadCustomers, int customersQued, double queTime, int köar, String queSize ){
		return (tid +" "+ event +" "+ kund +" "+ status +" "+ led +" "+ ledT +" "+ currentCustomers +" "+ cashOuts
				+" "+ sadCustomers +" "+ customersQued +" "+ queTime +" "+ köar +" "+ queSize );
	}

	public String headLine(){
		return "PARAMETRAR \n " +
				"========== \n " +
		"Antal kassor, N..........:"+ ((ShopState) state).totCheckouts + "\n"  +
		"Max som ryms, M..........: 7 \n" +
		"Ankomshastighet, lambda..: 3.0 \n" +
		"Plocktider, [P_min..Pmax]: [0.6..0.9] \n" +
		"Betaltider, [K_min..Kmax]: [0.35..0.6]\n" +
		"Frö, f...................: 13 \n" +
		"FÖRLOPP \n" +
				"======";
	}



	public void update(Observable arg0, Object arg1) {
		System.out.println("update");
		state = sim.getState();
	}



}
