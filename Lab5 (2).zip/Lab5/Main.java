package Lab5;

import Lab5.genericsimulator.Simulator;
import Lab5.genericsimulator.StartEvent;
import Lab5.genericsimulator.State;
import Lab5.genericsimulator.StopEvent;
import Lab5.genericsimulator.View;
import Lab5.genericsimulator.random.ExponentialRandomStream;
import Lab5.genericsimulator.random.UniformRandomStream;
import Lab5.shopsimulator.ShopState;
import Lab5.shopsimulator.shopevents.CloseEvent;

public class Main {

	public static void main(String[] args) {
		
		ExponentialRandomStream expR = new ExponentialRandomStream(0); // Skapar alla instanser av objekt som används
		UniformRandomStream uniR = new UniformRandomStream(0, 100);
		State state  = new ShopState(2000, expR , uniR );
		Simulator sim = new Simulator(state);
		
		sim.getEventQueue().add(new StartEvent(state, 10, sim.getEventQueue())); // Lägger till 3 events till eventQueue och kör sedan simulatorn
		sim.getEventQueue().add(new CloseEvent(state, 100, sim.getEventQueue()));
		sim.getEventQueue().add(new StopEvent(state, 1000, sim.getEventQueue()));
		sim.run();
		
		
	}
	
	
}
